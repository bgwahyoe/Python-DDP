# Harga masing-masing barang (tetap)
harga_minyak = 25000
harga_indomie = 5000
harga_beras = 75000
harga_gula = 25000
harga_kopi = 20000
harga_teh = 10000

# Meminta pengguna memasukkan jumlah barang
jumlah_minyak = int(input("Masukkan jumlah minyak: "))
jumlah_indomie = int(input("Masukkan jumlah indomie: "))
jumlah_beras = int(input("Masukkan jumlah beras: "))
jumlah_gula = int(input("Masukkan jumlah gula: "))
jumlah_kopi = int(input("Masukkan jumlah kopi: "))
jumlah_teh = int(input("Masukkan jumlah teh: "))

# Menghitung total harga masing-masing barang
total_minyak = harga_minyak * jumlah_minyak
total_indomie = harga_indomie * jumlah_indomie
total_beras = harga_beras * jumlah_beras
total_gula = harga_gula * jumlah_gula
total_kopi = harga_kopi * jumlah_kopi
total_teh = harga_teh * jumlah_teh

# Menghitung total pembelian
total_pembelian = (total_minyak + total_indomie + total_beras + 
                   total_gula + total_kopi + total_teh)

# Menghitung total setelah diskon (jika ada)
total_setelah_diskon = total_pembelian * 0.9 if total_pembelian > 100000 else total_pembelian

# Mencetak hasil
print(f"\nTotal harga: Rp {total_pembelian}")
if total_pembelian > 100000:
    print("Anda mendapatkan diskon 10%! Total setelah diskon: Rp", total_setelah_diskon)
else:
    print("Anda tidak mendapatkan diskon.")

# Mencetak total yang harus dibayar
total_yang_harus_dibayar = total_setelah_diskon
print(f"Total yang harus dibayar: Rp {total_yang_harus_dibayar:.2f}")
