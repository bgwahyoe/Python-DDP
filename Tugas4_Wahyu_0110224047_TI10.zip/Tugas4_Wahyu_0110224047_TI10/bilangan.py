bilangan = int(input("Masukkan bilangan :"))

if bilangan % 2 == 0 :  
  print(bilangan, "adalah bilang genap")
else :  
  print(bilangan, "adalah bilang ganjil")
  