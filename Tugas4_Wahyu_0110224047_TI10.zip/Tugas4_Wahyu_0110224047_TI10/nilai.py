nilai = int(input("Masukkan nilai : "))

if nilai >= 75 :  
  print("Lulus")
else :  
  print("Tidak lulus")
  