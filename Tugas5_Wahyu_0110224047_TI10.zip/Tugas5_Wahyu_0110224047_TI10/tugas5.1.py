# Nama : Wahyu Ahmad Yassin
# NIM : 0110224047
# Rombel : TI10

kendaraan = ['beat karbu', 'motor', 200, 'biru', 1]

kendaraan.append('15jt')
kendaraan.append('matic')
print(kendaraan)

kendaraan.insert(2, 'honda')
print(kendaraan)

print(type(kendaraan))
print(type(kendaraan[0]))
print(type(kendaraan[1]))
print(type(kendaraan[2]))
print(type(kendaraan[3]))
print(type(kendaraan[4]))
print(type(kendaraan[5]))
print(type(kendaraan[6]))
print(type(kendaraan[7]))
